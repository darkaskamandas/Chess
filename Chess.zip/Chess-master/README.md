Chess
=====

Chess game made under Unity.

A tutorial is made based on this game and can be found on my blog : 
http://learninggeekblog.wordpress.com/
